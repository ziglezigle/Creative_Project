module com.example.creative_project {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.creative_project to javafx.fxml;
    exports com.example.creative_project;
}