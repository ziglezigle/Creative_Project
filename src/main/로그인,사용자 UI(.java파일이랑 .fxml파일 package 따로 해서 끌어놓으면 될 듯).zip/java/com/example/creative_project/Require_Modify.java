package com.example.creative_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;

public class Require_Modify {

    @FXML
    private Button btn_add_require;

    @FXML
    private MenuButton mb_choose;

    @FXML
    private MenuItem menu_food;

    @FXML
    private MenuItem menu_playland;

    @FXML
    private TextArea ta_require;

    @FXML
    void add_require(ActionEvent event) {

    }

    @FXML
    void choose_food(ActionEvent event) {

    }

    @FXML
    void choose_playland(ActionEvent event) {

    }

}
