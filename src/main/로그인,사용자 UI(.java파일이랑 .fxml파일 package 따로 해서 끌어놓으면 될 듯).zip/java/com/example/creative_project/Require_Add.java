package com.example.creative_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class Require_Add {

    @FXML
    private Button btn_add_list;

    @FXML
    private MenuButton mb_choose_Do;

    @FXML
    private MenuButton mb_choose_Si;

    @FXML
    private MenuButton mb_choose_list;

    @FXML
    private MenuItem menu_food_list;

    @FXML
    private MenuItem menu_playland_list;

    @FXML
    private TextArea ta_require;

    @FXML
    private TextField tf_nameOf_there;

    @FXML
    void add_require_list(ActionEvent event) {

    }

    @FXML
    void choose_Do(ActionEvent event) {

    }

    @FXML
    void choose_Si(ActionEvent event) {

    }

    @FXML
    void choose_food_list(ActionEvent event) {

    }

    @FXML
    void choose_playland_list(ActionEvent event) {

    }

}
