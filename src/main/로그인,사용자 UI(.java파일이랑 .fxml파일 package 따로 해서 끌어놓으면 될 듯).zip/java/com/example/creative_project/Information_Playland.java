package com.example.creative_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class Information_Playland {

    @FXML
    private Button btn_search_playland;

    @FXML
    private MenuButton mb_information_Do;

    @FXML
    private MenuButton mb_information_Si;

    @FXML
    private TableColumn<?, ?> tc_playland_address;

    @FXML
    private TableColumn<?, ?> tc_playland_name;

    @FXML
    private TableColumn<?, ?> tc_playland_review;

    @FXML
    private TableColumn<?, ?> tc_playland_score;

    @FXML
    private TableColumn<?, ?> tc_playland_sort;

    @FXML
    private TextField tf_search_playland;

    @FXML
    private TableView<?> tv_information_playland;

    @FXML
    void view_search_playland(ActionEvent event) {

    }

}
